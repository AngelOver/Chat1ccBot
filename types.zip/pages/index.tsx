export { default, getServerSideProps } from './api/home';
